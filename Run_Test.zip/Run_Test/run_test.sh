#!/bin/bash 

# Using bash script to test CUDA GPU environment and run KMC2D 
# 1. Check NVIDIA Hardware Environment
# 2. Check CUDA and NVIDIA Package Software Environment for the Redhat or Debian Linux
# 3. Parse the necessary parameters for KMC2D
# 5. Run KMC2D at the Command Line version 
# Usage: ./run_test.sh z_genotype_file w_geno_file kinship_file
# Writter: Wenchao Zhang
# ---------------------------------------------------------------

grep -Ei 'redhat|centos' /etc/*release
if [[ $? -eq "0" ]]
then
  os_redhat=true
  echo "you are working in redhat like linux"
else
  os_redhat=false
fi

grep -Ei 'debian|ubuntu' /etc/*release
if [[ $? -eq "0" ]]
then
  os_debian=true
  echo "you are working in debian like linux"
else
  os_debian=false
fi

echo "Welcome to test your CUDA GPU Environment and Run KMC2D: $0, $1, $2, $3"
## Begin to check the GPU hardare and software environment
nvidia_hardware_num=`lspci|grep -i nvidia|wc -l` # NVIDIA Slice umber==0, nvidia hardware is not avaiale 
if [[ $nvidia_hardware_num -eq "0" ]]
then
   echo "you need NVIDIA CUDA-Capable GPU hardware in your linux envrionment" 
   exit
else
   echo "Your linux platform have $nvidia_hardware_num NVIDIA GPU Cards"
fi

$os_redhat && cuda_software_num1=`rpm -qa |grep cuda| wc -l` || cuda_software_num1=0
$os_debian && cuda_software_num=`dpkg -l |grep cuda| wc -l` || cuda_software_num=$cuda_software_num1

if [[ $cuda_software_num -eq "0" ]]
then
   echo "you need intsall CUDA related packages" 
   exit
fi

$os_redhat && nvidia_software_num=`rpm -qa |grep nvidia| wc -l` ||nvidia_software_num=0
$os_debian && nvidia_software_num=`dpkg -l |grep nvidia| wc -l` ||nvidia_software_num=0 

if [[ $cuda_software_num -eq "0" ]]
then
   echo "you need intsall NIVIDIA related packages" 
   exit
fi

## Begin to parse the input parameters for KMC2D  
z_file=$1
w_file=$2
individual_num=`head -n 1 $z_file |tr "," "\n"|wc -l`
if [ $individual_num -le 1 ]  
then
  individual_num=`head -n 1 $z_file |tr "\t" "\n"|wc -l`
fi

if [ $individual_num -le 1 ]
then
  echo "The z genotype file are in wrong format, which should be comma separated file"
  exit
fi

w_individual_num=`head -n 1 $w_file |tr "," "\n"|wc -l`
if [ $w_individual_num -le 1 ]  
then
  w_individual_num=`head -n 1 $w_file |tr "\t" "\n"|wc -l`
fi

if [[ $individual_num -ne $w_individual_num ]]
then
  echo "The w genotype file are in wrong column format, which should be matched with z genotype file"
  exit
fi

marker_num=`wc -l $z_file`
w_marker_num=`wc -l $w_file`

if [[ $marker_num -ne $w_marker_num ]]
then
  echo "The w genotype file are in wrong row format, which should be matched with z genotype file"
  exit
fi

## Begin to call KMC2D to parallel calculating 2D kinship matrix
if [[ ! -e ./KMC2D ]]
then
   echo "You need an executable file of KMC2D with this shell script, please use Makefile to compile it at first! "
   exit
fi

kinship_file=$3
marker_block=2000 #2000 Markers as a block 
run_mode=0  # GPU Parallel
echo "Now, you are runing a GPU parallel program KMC2D to calculate the kinship matrix! "
echo "Your Parameters for KMC2D--Z_Genotype_File:$z_file, W_Genotype_File:$w_file, Kinship_File:$kinship_file, Indiviudal_Num:$individual_num, Marker_length: $marker_num,  Blcok:$marker_block, run_mode:$run_mode"
./KMC2D -z $z_file -w $w_file -k $kinship_file -i $individual_num -l $marker_num -b $marker_block -m $run_mode
if [[ $? -eq 0 ]]
then
echo "KMC2D Successfully Finished!"
else
echo "Call KMC2D Failed!"
fi



